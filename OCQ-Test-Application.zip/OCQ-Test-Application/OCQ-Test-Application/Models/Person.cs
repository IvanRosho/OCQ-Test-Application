﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OCQ_Test_Application.Models
{
    public partial class Person
    {
        public int Id { get; set; }
        public string Forename { get; set; }
        public string Lastname { get; set; }
        public string Comment { get; set; }
    }
}
